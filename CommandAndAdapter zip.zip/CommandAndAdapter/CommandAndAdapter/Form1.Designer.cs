﻿namespace CommandAndAdapter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.doActionButton = new System.Windows.Forms.Button();
            this.redoButton = new System.Windows.Forms.Button();
            this.undoButton = new System.Windows.Forms.Button();
            this.actionsLB = new System.Windows.Forms.ListBox();
            this.actionCB = new System.Windows.Forms.ComboBox();
            this.optionCB = new System.Windows.Forms.ComboBox();
            this.healthLabel = new System.Windows.Forms.Label();
            this.happinessLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // doActionButton
            // 
            this.doActionButton.Enabled = false;
            this.doActionButton.Location = new System.Drawing.Point(374, 32);
            this.doActionButton.Name = "doActionButton";
            this.doActionButton.Size = new System.Drawing.Size(92, 23);
            this.doActionButton.TabIndex = 0;
            this.doActionButton.Text = "Do The Thing";
            this.doActionButton.UseVisualStyleBackColor = true;
            this.doActionButton.Click += new System.EventHandler(this.doActionButton_Click);
            // 
            // redoButton
            // 
            this.redoButton.Enabled = false;
            this.redoButton.Location = new System.Drawing.Point(292, 76);
            this.redoButton.Name = "redoButton";
            this.redoButton.Size = new System.Drawing.Size(75, 23);
            this.redoButton.TabIndex = 1;
            this.redoButton.Text = "Redo";
            this.redoButton.UseVisualStyleBackColor = true;
            this.redoButton.Click += new System.EventHandler(this.redoButton_Click);
            // 
            // undoButton
            // 
            this.undoButton.Enabled = false;
            this.undoButton.Location = new System.Drawing.Point(199, 76);
            this.undoButton.Name = "undoButton";
            this.undoButton.Size = new System.Drawing.Size(75, 23);
            this.undoButton.TabIndex = 2;
            this.undoButton.Text = "Undo";
            this.undoButton.UseVisualStyleBackColor = true;
            this.undoButton.Click += new System.EventHandler(this.undoButton_Click);
            // 
            // actionsLB
            // 
            this.actionsLB.FormattingEnabled = true;
            this.actionsLB.Location = new System.Drawing.Point(25, 125);
            this.actionsLB.Name = "actionsLB";
            this.actionsLB.Size = new System.Drawing.Size(501, 459);
            this.actionsLB.TabIndex = 3;
            // 
            // actionCB
            // 
            this.actionCB.AllowDrop = true;
            this.actionCB.FormattingEnabled = true;
            this.actionCB.Items.AddRange(new object[] {
            "Eat",
            "Do",
            "Go to"});
            this.actionCB.Location = new System.Drawing.Point(71, 35);
            this.actionCB.Name = "actionCB";
            this.actionCB.Size = new System.Drawing.Size(121, 21);
            this.actionCB.TabIndex = 4;
            this.actionCB.Text = "Select Action...";
            this.actionCB.SelectedIndexChanged += new System.EventHandler(this.actionCB_SelectedIndexChanged);
            // 
            // optionCB
            // 
            this.optionCB.FormattingEnabled = true;
            this.optionCB.Location = new System.Drawing.Point(214, 34);
            this.optionCB.Name = "optionCB";
            this.optionCB.Size = new System.Drawing.Size(138, 21);
            this.optionCB.TabIndex = 5;
            this.optionCB.SelectedIndexChanged += new System.EventHandler(this.optionCB_SelectedIndexChanged);
            // 
            // healthLabel
            // 
            this.healthLabel.AutoSize = true;
            this.healthLabel.Location = new System.Drawing.Point(22, 607);
            this.healthLabel.Name = "healthLabel";
            this.healthLabel.Size = new System.Drawing.Size(106, 13);
            this.healthLabel.TabIndex = 6;
            this.healthLabel.Text = "My health level is 75.";
            // 
            // happinessLabel
            // 
            this.happinessLabel.AutoSize = true;
            this.happinessLabel.Location = new System.Drawing.Point(401, 602);
            this.happinessLabel.Name = "happinessLabel";
            this.happinessLabel.Size = new System.Drawing.Size(125, 13);
            this.happinessLabel.TabIndex = 7;
            this.happinessLabel.Text = "My happiness level is 75.";
            this.happinessLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(551, 624);
            this.Controls.Add(this.happinessLabel);
            this.Controls.Add(this.healthLabel);
            this.Controls.Add(this.optionCB);
            this.Controls.Add(this.actionCB);
            this.Controls.Add(this.actionsLB);
            this.Controls.Add(this.undoButton);
            this.Controls.Add(this.redoButton);
            this.Controls.Add(this.doActionButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button doActionButton;
        private System.Windows.Forms.Button redoButton;
        private System.Windows.Forms.Button undoButton;
        private System.Windows.Forms.ListBox actionsLB;
        private System.Windows.Forms.ComboBox actionCB;
        private System.Windows.Forms.ComboBox optionCB;
        private System.Windows.Forms.Label healthLabel;
        private System.Windows.Forms.Label happinessLabel;
    }
}

