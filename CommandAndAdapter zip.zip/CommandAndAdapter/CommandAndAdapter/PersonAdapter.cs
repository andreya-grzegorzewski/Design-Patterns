﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommandAndAdapter
{
    class PersonAdapter : NewPerson // This is the adapter class
    {
        LegacyPerson lp = new LegacyPerson();

        public override int[] doThing(bool healthy, bool happy)
        {
            if (healthy)
                lp.doHealthyThing();
            else
                lp.doUnhealthyThing();
            if (happy)
                lp.doHappyThing();
            else
                lp.doUnhappyThing();

            int[] healthyHappy = new int[2];
            healthyHappy[0] = lp.getHealth();
            healthyHappy[1] = lp.getHappiness();

            return healthyHappy;
        }

        public override string getHealthyText()
        {
            return base.getHealthyText() + lp.getHealth() + ".";
        }

        public override string getHappyText()
        {
            return base.getHappyText() + lp.getHappiness() + ".";
        }
    }
}
