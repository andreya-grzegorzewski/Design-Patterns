﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommandAndAdapter
{
    class LegacyPerson // This is the adaptee class, which represents the poorly written legacy code of a person class. 
    {
        int health = 75;
        int happiness = 75;

        const int GOOD_DECISION_ADDITION = 5;
        const int BAD_DECISION_DETRACTION = -5;

        public void doHealthyThing()
        {
            health += GOOD_DECISION_ADDITION;
        }

        public void doUnhealthyThing()
        {
            health += BAD_DECISION_DETRACTION;
        }

        public void doHappyThing()
        {
            happiness += GOOD_DECISION_ADDITION;
        }

        public void doUnhappyThing()
        {
            happiness += BAD_DECISION_DETRACTION;
        }

        public int getHealth()
        {
            return health;
        }

        public int getHappiness()
        {
            return happiness;
        }
    }
}
