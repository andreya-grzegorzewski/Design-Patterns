﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CommandAndAdapter
{
    public partial class Form1 : Form
    {
        Stack<ConcreteCommand> undoStack = new Stack<ConcreteCommand>();
        Stack<ConcreteCommand> redoStack = new Stack<ConcreteCommand>();

        NewPerson person = new PersonAdapter();
        ConcreteCommand cc;

        // The healthy and happy values for each of the options shown in the combo boxes.
        bool[,] healthyHappy = new bool[,]
        {
            { false, true }, { true, false }, { true, true },
            { true, false }, { false, true }, { true, true },
            { true, true },  { true, false }, { false, true }
        };

        public Form1()
        {
            InitializeComponent();
        }

        private void actionCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = actionCB.SelectedIndex;
            optionCB.Items.Clear();

            switch (index)
            {
                case 0: // The user selected "Eat"
                    optionCB.Text = "Select food...";
                    optionCB.Items.Add("Cake");
                    optionCB.Items.Add("Salad");
                    optionCB.Items.Add("Strawberries");
                    break;
                case 1: // The user selected "Do"
                    optionCB.Text = "Select action to do...";
                    optionCB.Items.Add("A workout");
                    optionCB.Items.Add("Nothing all day");
                    optionCB.Items.Add("A barrel roll");
                    break;
                case 2: // The user selected "Go to"
                    optionCB.Text = "Select a place to go...";
                    optionCB.Items.Add("Sleep");
                    optionCB.Items.Add("The dentist");
                    optionCB.Items.Add("An ice cream shop");
                    break;
                default:
                    MessageBox.Show("actionCB.SelectedIndex = " + index + " in actionCB event method.");
                    break;
            }
            optionCB.AllowDrop = true;
        }

        // Create command for the action and selected option
        private void doActionButton_Click(object sender, EventArgs e)
        {
            cc = null;
            string actionText = actionCB.GetItemText(actionCB.SelectedItem).ToLower();

            if (actionText == "eat")
                actionText = "regurgitate";
            else if (actionText == "go to")
                actionText = "return from";
            else if (actionText == "do")
                actionText = "undo";

            string commandText = "I will " + actionText + " " + optionCB.GetItemText(optionCB.SelectedItem).ToLower() + ".";
            undoButton.Enabled = true;

            switch (optionCB.GetItemText(optionCB.SelectedItem))
            {
                case "Cake":
                    cc = new ConcreteCommand(person, healthyHappy[0, 0], healthyHappy[0, 1], commandText);
                    break;
                case "Salad":
                    cc = new ConcreteCommand(person, healthyHappy[1, 0], healthyHappy[1, 1], commandText);
                    break;
                case "Strawberries":
                    cc = new ConcreteCommand(person, healthyHappy[2, 0], healthyHappy[2, 1], commandText);
                    break;
                case "A workout":
                    cc = new ConcreteCommand(person, healthyHappy[3, 0], healthyHappy[3, 1], commandText);
                    break;
                case "Nothing all day":
                    cc = new ConcreteCommand(person, healthyHappy[4, 0], healthyHappy[4, 1], commandText);
                    break;
                case "A barrel roll":
                    cc = new ConcreteCommand(person, healthyHappy[5, 0], healthyHappy[5, 1], commandText);
                    break;
                case "Sleep":
                    cc = new ConcreteCommand(person, healthyHappy[6, 0], healthyHappy[6, 1], commandText);
                    break;
                case "The dentist":
                    cc = new ConcreteCommand(person, healthyHappy[7, 0], healthyHappy[7, 1], commandText);
                    break;
                case "An ice cream shop":
                    cc = new ConcreteCommand(person, healthyHappy[8, 0], healthyHappy[8, 1], commandText);
                    break;
                default:
                    MessageBox.Show(optionCB.SelectedValue.ToString());
                    break;
            }

            if (cc != null)
            {
                cc.execute();
                undoStack.Push(cc);
                actionsLB.Items.Add("I will " + actionCB.GetItemText(actionCB.SelectedItem).ToLower() + " " + optionCB.GetItemText(optionCB.SelectedItem).ToLower() + ".");
                healthLabel.Text = person.getHealthyText();
                happinessLabel.Text = person.getHappyText();
            }
        }

        private void undoButton_Click(object sender, EventArgs e)
        {
            redoButton.Enabled = true;
            cc = undoStack.Pop();
            string nextText = cc.unexecute(); 
            redoStack.Push(cc);

            actionsLB.Items.Add(nextText);
            healthLabel.Text = person.getHealthyText();
            happinessLabel.Text = person.getHappyText();

            if (undoStack.Count == 0)
                undoButton.Enabled = false;
        }

        private void redoButton_Click(object sender, EventArgs e)
        {
            undoButton.Enabled = true;
            cc = redoStack.Pop();
            string nextText = cc.execute();
            undoStack.Push(cc);

            actionsLB.Items.Add(nextText);
            healthLabel.Text = person.getHealthyText();
            happinessLabel.Text = person.getHappyText();

            if (redoStack.Count == 0)
                redoButton.Enabled = false;
        }

        private void optionCB_SelectedIndexChanged(object sender, EventArgs e)
        {
            doActionButton.Enabled = true;
        }
    }
}
