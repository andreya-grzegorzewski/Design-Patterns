﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommandAndAdapter
{
    class ConcreteCommand : Command // This is the concrete command class
    {
        NewPerson person;
        bool healthy;
        bool happy;
        string text;

        public ConcreteCommand(NewPerson person, bool healthy, bool happy, string text)
        {
            this.person = person;
            this.healthy = healthy;
            this.happy = happy;
            this.text = text;
        }

        public override string execute()
        {
            person.doThing(healthy, happy);
            text = getNewText();
            return text;
        }

        public override string unexecute()
        {
            person.doThing(!healthy, !happy);
            text = getNewText();
            return text;
        }

        private string getNewText()
        {
            string oldText = this.text;
            string newText = "newText";

            if (oldText.Contains(" eat "))
                newText = oldText.Replace("eat", "regurgitate");
            else if (oldText.Contains(" regurgitate "))
                newText = oldText.Replace(" regurgitate ", " eat ");
            else if (oldText.Contains(" do "))
                newText = oldText.Replace(" do ", " undo ");
            else if (oldText.Contains(" undo "))
                newText = oldText.Replace(" undo ", " do ");
            else if (oldText.Contains(" go to "))
                newText = oldText.Replace(" go to ", " return from ");
            else if (oldText.Contains(" return from "))
                newText = oldText.Replace(" return from ", " go to ");

            this.text = newText;
            return newText;
        }
    }
}
