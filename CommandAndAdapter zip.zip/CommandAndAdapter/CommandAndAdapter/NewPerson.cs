﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommandAndAdapter
{
    public abstract class NewPerson // This is the receiver class for the command pattern and the target class for the adapter pattern
    {
        public abstract int[] doThing(bool healthy, bool happy);
        
        public virtual string getHappyText()
        {
            return "My happiness level is ";
        }

        public virtual string getHealthyText()
        {
            return "My health level is ";
        }
    }
}
