﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommandAndAdapter
{
    public abstract class Command // This is the abstract command class
    {
        public abstract string execute();
        public abstract string unexecute();
    }
}
