﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scales
{
    class MelodicMinorScale : Scale // This is a concrete strategy
    {
        public override int[] getScaleIndices()
        {
            int[] indices = { 0, 2, 3, 5, 7, 9, 11, 12, 10, 8, 7, 5, 3, 2, 0 };
            return indices;
        }

        public override string ToString()
        {
            return "Melodic minor scale";
        }
    }
}
