﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scales
{
    class MajorScale : Scale   // This is a concrete strategy
    {
        public override int[] getScaleIndices()
        {
            int[] indices = { 0, 2, 4, 5, 7, 9, 11, 12, 11, 9, 7, 5, 4, 2, 0 };
            return indices;
        }

        public override string ToString()
        {
            return "Major scale";
        }
    }
}
