﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scales
{
    class Pianist   // This is the Context class
    {
        Scale scale;    // Contains a scale of any type
        int startIndex; // Contains the start note, or key signature

        public Pianist(Scale scale, int startIndex)
        {
            this.scale = scale;
            this.startIndex = startIndex;
        }

        public string[] playScale()
        {
            string[] scaleNotes = scale.getScale(startIndex);
            return scaleNotes;
        }
    }
}
