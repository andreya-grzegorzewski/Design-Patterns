﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scales
{
    class HarmonicMinorScale : Scale // This is a concrete strategy
    {
        public override int[] getScaleIndices()
        {
            int[] indices = { 0, 2, 3, 5, 7, 8, 11, 12, 11, 8, 7, 5, 3, 2, 0 };
            return indices;
        }

        public override string ToString()
        {
            return "Harmonic minor scale";
        }
    }
}
