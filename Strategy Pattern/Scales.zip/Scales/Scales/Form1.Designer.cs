﻿namespace Scales
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.scaleTypeCB = new System.Windows.Forms.ComboBox();
            this.keySignatureCB = new System.Windows.Forms.ComboBox();
            this.displayButton = new System.Windows.Forms.Button();
            this.scaleLB = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // scaleTypeCB
            // 
            this.scaleTypeCB.FormattingEnabled = true;
            this.scaleTypeCB.Location = new System.Drawing.Point(27, 27);
            this.scaleTypeCB.Name = "scaleTypeCB";
            this.scaleTypeCB.Size = new System.Drawing.Size(134, 21);
            this.scaleTypeCB.TabIndex = 0;
            this.scaleTypeCB.Text = "Select scale type...";
            // 
            // keySignatureCB
            // 
            this.keySignatureCB.FormattingEnabled = true;
            this.keySignatureCB.Location = new System.Drawing.Point(27, 54);
            this.keySignatureCB.Name = "keySignatureCB";
            this.keySignatureCB.Size = new System.Drawing.Size(134, 21);
            this.keySignatureCB.TabIndex = 1;
            this.keySignatureCB.Text = "Select key signature...";
            // 
            // displayButton
            // 
            this.displayButton.Location = new System.Drawing.Point(27, 107);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(134, 23);
            this.displayButton.TabIndex = 2;
            this.displayButton.Text = "Display Scale";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // scaleLB
            // 
            this.scaleLB.FormattingEnabled = true;
            this.scaleLB.Location = new System.Drawing.Point(204, 27);
            this.scaleLB.Name = "scaleLB";
            this.scaleLB.Size = new System.Drawing.Size(120, 212);
            this.scaleLB.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(362, 294);
            this.Controls.Add(this.scaleLB);
            this.Controls.Add(this.displayButton);
            this.Controls.Add(this.keySignatureCB);
            this.Controls.Add(this.scaleTypeCB);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox scaleTypeCB;
        private System.Windows.Forms.ComboBox keySignatureCB;
        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.ListBox scaleLB;
    }
}

