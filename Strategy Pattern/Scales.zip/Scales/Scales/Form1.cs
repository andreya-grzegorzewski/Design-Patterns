﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Scales
{
    public partial class Form1 : Form
    {
        Pianist pianist;
           
        public Form1()
        {
            InitializeComponent();

            scaleTypeCB.Items.Add(new MajorScale());
            scaleTypeCB.Items.Add(new NaturalMinorScale());
            scaleTypeCB.Items.Add(new HarmonicMinorScale());
            scaleTypeCB.Items.Add(new MelodicMinorScale());

            keySignatureCB.Items.Add("A");
            keySignatureCB.Items.Add("B\u266D");
            keySignatureCB.Items.Add("B");
            keySignatureCB.Items.Add("C");
            keySignatureCB.Items.Add("C#");
            keySignatureCB.Items.Add("D");
            keySignatureCB.Items.Add("E\u266D");
            keySignatureCB.Items.Add("E");
            keySignatureCB.Items.Add("F");
            keySignatureCB.Items.Add("F#");
            keySignatureCB.Items.Add("G");
            keySignatureCB.Items.Add("A\u266D");
        }


        private void displayButton_Click(object sender, EventArgs e)
        {
            // Get the scale notes
            int startIndex = keySignatureCB.SelectedIndex;
            pianist = new Pianist((Scale)scaleTypeCB.SelectedItem, startIndex);
            string[] scaleNotes = pianist.playScale();

            scaleLB.Items.Clear();

            // Indent and display the notes
            for (int i = 0; i <= scaleNotes.Length / 2; i++)
            {
                string indent = "";
                for (int j = 0; j < i; j++)
                    indent += "  ";

                scaleLB.Items.Add(indent + scaleNotes[i]);
            }

            // Descrease the indent on the way down
            int iDecrease = 2;
            for (int i = scaleNotes.Length / 2 + 1; i < scaleNotes.Length; i++)
            {
                string indent = "";
                for (int j = 0; j < i - iDecrease; j++)
                    indent += "  ";

                scaleLB.Items.Add(indent + scaleNotes[i]);
                iDecrease += 2;
            }
        }
    }
}
