﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scales
{
    public abstract class Scale    // This is the IStrategy interface, implemented here as an abstract class
    {
        // This method will return the zero-based indices of the appropriate type of scale;
        // For example, if I wanted C - D - E - F - G, I would return 0, 2, 4, 5, 7.
        // I would return the same thing for D - E - F# - G - A.
        // This is based on the pattern of half-steps and whole-steps in the definition of each scale type.
        public abstract int[] getScaleIndices();

        // This method returns the scale, bottom to top to bottom. The top note is not repeated.
        public string[] getScale(int startIndex)
        {
            string[] scale = new string[15]; 
            // Have to use two different arrays - Scales usually use either all sharp or all flat notes
            string[] flatNotes = { "A", "B\u266D", "B", "C", "D\u266D", "D", "E\u266D", "E", "F", "G\u266D", "G", "A\u266D" };
            string[] sharpNotes = { "A", "A#", "B", "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#" };

            // Assume we'll be using flat notes, then change it to sharp notes if we need to
            string[] notes = flatNotes;
            switch (startIndex)
            {
                case 0: case 2: case 4: case 5: case 7: case 9: case 10:
                    notes = sharpNotes;
                    break;
            }

            int[] indices = getScaleIndices();

            // Switch to flat notes for D and G minor scales
            if ((startIndex == 10 || startIndex == 5) && indices[2] == 3)
                notes = flatNotes;

            // Assign notes based on scale indices and the start index
            for (int i = 0; i < indices.Length; i++) 
            {
                int index = startIndex + indices[i];
                if (index > 11)
                    index -= 12;

                scale[i] = notes[index];
            }

            // If there are two notes with the same note name, replace one
            for (int i = 65; i <= 71; i++)  // For A to G
                if (containsTwoOf(scale, ((char)i).ToString()))
                    replace(scale, ((char)i).ToString());

            // Catches the problem of getting D-flat and D or G-flat and G both in one scale
            if ((scale[0] == "D" || scale[0] == "G") && indices[2] == 3)
                replace(scale, notes[startIndex] + "\u266D");

            // Catches a similar problem with E-flat and A-flat minor scales
            if ((scale[0] == "E\u266D" || scale[0] == "A\u266D") && indices[2] == 3)
                replace(scale, notes[startIndex - 4]);

            return scale;
        }

        private bool containsTwoOf(string[] thisScale, string note)
        {
            bool flag1 = false;
            bool flag2 = false;

            for (int i = 0; i < thisScale.Length / 2; i++)
            {
                if (thisScale[i].Contains(note))
                {
                    if (!flag1)
                        flag1 = true;
                    else
                        flag2 = true;
                }
            }
            return flag1 && flag2;
        }

        private void replace(string[] thisScale, string note)
        {
            char[] noteChar = note.ToCharArray();
            switch (note)
            {
                // Replaces C with B-sharp, F with E-sharp, and so on
                case "C":
                case "F":
                case "D\u266D":
                case "G\u266D":
                    for (int i = 0; i < thisScale.Length; i++)
                        if (thisScale[i] == note)
                            thisScale[i] = (((char)(noteChar[0] - 1)).ToString()) + "#";
                    break;
                // Replaces B with C-flat and E with F-flat
                case "B":
                case "E":
                    for (int i = 0; i < thisScale.Length; i++)
                        if (thisScale[i] == note)
                            thisScale[i] = ((char)(noteChar[0] + 1)).ToString() + "\u266D";
                    break;
            }
        }
    }
}