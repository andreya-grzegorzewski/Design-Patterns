﻿namespace Composite
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.musicLB = new System.Windows.Forms.ListBox();
            this.removeButton = new System.Windows.Forms.Button();
            this.addMusicianButton = new System.Windows.Forms.Button();
            this.addSectionButton = new System.Windows.Forms.Button();
            this.sectionCB = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // musicLB
            // 
            this.musicLB.FormattingEnabled = true;
            this.musicLB.Location = new System.Drawing.Point(236, 20);
            this.musicLB.Name = "musicLB";
            this.musicLB.Size = new System.Drawing.Size(288, 394);
            this.musicLB.TabIndex = 0;
            // 
            // removeButton
            // 
            this.removeButton.Location = new System.Drawing.Point(12, 142);
            this.removeButton.Name = "removeButton";
            this.removeButton.Size = new System.Drawing.Size(120, 23);
            this.removeButton.TabIndex = 2;
            this.removeButton.Text = "Remove";
            this.removeButton.UseVisualStyleBackColor = true;
            this.removeButton.Click += new System.EventHandler(this.removeButton_Click);
            // 
            // addMusicianButton
            // 
            this.addMusicianButton.Location = new System.Drawing.Point(12, 82);
            this.addMusicianButton.Name = "addMusicianButton";
            this.addMusicianButton.Size = new System.Drawing.Size(120, 23);
            this.addMusicianButton.TabIndex = 3;
            this.addMusicianButton.Text = "Add Musician";
            this.addMusicianButton.UseVisualStyleBackColor = true;
            this.addMusicianButton.Click += new System.EventHandler(this.addMusicianButton_Click);
            // 
            // addSectionButton
            // 
            this.addSectionButton.Location = new System.Drawing.Point(144, 20);
            this.addSectionButton.Name = "addSectionButton";
            this.addSectionButton.Size = new System.Drawing.Size(58, 23);
            this.addSectionButton.TabIndex = 4;
            this.addSectionButton.Text = "Add";
            this.addSectionButton.UseVisualStyleBackColor = true;
            this.addSectionButton.Click += new System.EventHandler(this.addSectionButton_Click);
            // 
            // sectionCB
            // 
            this.sectionCB.FormattingEnabled = true;
            this.sectionCB.Location = new System.Drawing.Point(12, 22);
            this.sectionCB.Name = "sectionCB";
            this.sectionCB.Size = new System.Drawing.Size(121, 21);
            this.sectionCB.TabIndex = 6;
            this.sectionCB.Text = "Select Section...";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(541, 429);
            this.Controls.Add(this.sectionCB);
            this.Controls.Add(this.addSectionButton);
            this.Controls.Add(this.addMusicianButton);
            this.Controls.Add(this.removeButton);
            this.Controls.Add(this.musicLB);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox musicLB;
        private System.Windows.Forms.Button removeButton;
        private System.Windows.Forms.Button addMusicianButton;
        private System.Windows.Forms.Button addSectionButton;
        private System.Windows.Forms.ComboBox sectionCB;
    }
}

