﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Composite
{
    public partial class Form1 : Form
    {
        Section myOrchestra;    // The variable for the whole orchestra
        Section[] sections = new Section[5];    // 0 for orchestra; 1 for violins; 2 for violas; 3 for cellos; 4 for basses

        public Form1()
        {
            InitializeComponent();

            myOrchestra = new Section("My Orchestra");

            // Add the sections to the combo box for selecting sections
            sectionCB.Items.Add("Violins");
            sectionCB.Items.Add("Violas");
            sectionCB.Items.Add("Cellos");
            sectionCB.Items.Add("Basses");

            sections[0] = myOrchestra;

            updateLB();
        }

        private void updateLB()
        {
            // Reset the listbox and get the string array to add
            musicLB.Items.Clear();
            string[] stringArray = myOrchestra.ToStringArray();

            // For each element in the array
            for (int i = 0; i < 20 + myOrchestra.getCount(); i++)
            {
                // If the item is empty, break
                if (stringArray[i] == null)
                    break;

                // Otherwise, add the item to the listbox
                musicLB.Items.Add(stringArray[i]);
            }
        }

        private void addSectionButton_Click(object sender, EventArgs e)
        {
            // If the section is not already in the orchestra
            if (sections[sectionCB.SelectedIndex + 1] == null)
            {
                // Add the section to the array and the orchestra
                string secName = sectionCB.GetItemText(sectionCB.SelectedItem);
                Section sec = new Section(secName);
                myOrchestra.addComponent(sec);
                sections[sectionCB.SelectedIndex + 1] = sec;
            }
            // Otherwise, tell the user they can't do that.
            else
                MessageBox.Show("You already have one of those.");

            updateLB();
        }

        private void addMusicianButton_Click(object sender, EventArgs e)
        {
            int index = musicLB.SelectedIndex;

            if (musicLB.GetItemText(musicLB.SelectedItem).Contains("Violins"))
                sections[1].addComponent(new Musician());
            else if (musicLB.GetItemText(musicLB.SelectedItem).Contains("Violas"))
                sections[2].addComponent(new Musician());
            else if (musicLB.GetItemText(musicLB.SelectedItem).Contains("Cellos"))
                sections[3].addComponent(new Musician());
            else if (musicLB.GetItemText(musicLB.SelectedItem).Contains("Basses"))
                sections[4].addComponent(new Musician());

            else
                MessageBox.Show("Select a section to add the musician to.");

            // Update the listbox and set the selected index to the previously selected index
            updateLB();
            musicLB.SelectedIndex = index;
        }

        private void removeButton_Click(object sender, EventArgs e)
        {
            int indexToRemove = musicLB.SelectedIndex;

            int[] indices = new int[5]; // Index of the violin, viola, cello, and bass labels in the LB

            // Default the indices to -1.
            for (int i = 0; i < indices.Length; i++)
                indices[i] = -1;

            // If the section is present in the orchestra, set the index to the position of the section label in the listbox
            if (sections[4] != null)
                indices[4] = musicLB.FindString("    Basses (" + sections[4].getCount() + ")");

            if (sections[3] != null)
               indices[3] = musicLB.FindString("    Cellos (" + sections[3].getCount() + ")");

            if (sections[2] != null)
                indices[2] = musicLB.FindString("    Violas (" + sections[2].getCount() + ")");

            if (sections[1] != null)
                indices[1] = musicLB.FindString("    Violins (" + sections[1].getCount() + ")");
        
            // For each section in the array
            for (int i = 0; i < sections.Length - 1; i++)
            {
                // Start with the last section in the listbox
                // Get this index by finding the max index listed in indices.
                int num = indices.Max();
                int index = -1;

                for (int j = 0; j < indices.Length; j++)
                    if (indices[j] == num)
                        index = j;

                // If a musician in this section is selected, remove that musician
                if (indexToRemove > indices[index] && indices[index] != -1)
                    sections[index].removeComponent(new Musician((musicLB.GetItemText(musicLB.SelectedItem)).Trim()));

                // If the section is selected, remove the section
                else if (indexToRemove == indices[index])
                {
                    myOrchestra.removeComponent(sections[index]);
                    sections[index] = null;
                }

                // Change this index to -2 so it isn't checked again
                indices[index] = -2;
            }
            updateLB();
        }
    }
}
