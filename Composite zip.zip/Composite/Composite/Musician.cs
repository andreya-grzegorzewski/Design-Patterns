﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Composite
{
    class Musician : Component  // Leaf class
    {
        public Musician(string name)
        {
            this.name = name;
        }

        public Musician()
        {
            string first = names[rngesus.Next(names.Length)];
            char last = (char)rngesus.Next(65, 91);

            name = first + " " + last.ToString() + ".";
        }

        string name = "";
        Random rngesus = new Random();
        string[] names = { "Andreya", "Andrew", "Ben", "Claire", "David", "Eugene",
                           "Francine", "Greg", "Harry", "Jaired", "Jacob", "Jack",
                           "Julie", "James", "Kevin", "Leonard", "Ophelia", "Penny",
                           "Rachel", "Steven", "Tori", "Violet", "William"};

        public int getCount()
        {
            return 1;
        }

        public override string ToString()
        {
            return "    " + name;
        }

        public override bool Equals(Object obj)
        {
            if (obj == null || this.GetType() != obj.GetType())
                return false;

            Musician m = (Musician)obj;
            return name == m.name;
        }
    }
}
