﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Composite
{
    class Section : Component   // Composite class
    {
        List<Component> children = new List<Component>();
        string name = "";

        public Section(string name)
        {
            this.name = name;
        }

        // Adds up the counts of all of the children of the section
        public int getCount()
        {
            int count = 0;
            for (int i = 0; i < children.Count; i++)
                count += getChild(i).getCount();

            return count;
        }

        public override string ToString()
        {
            return name + " (" + getCount() + ")";
        }

        public void addComponent(Component comp)
        {
            children.Add(comp);
        }

        public void removeComponent(Component comp)
        {
            if (children.Contains(comp))
                children.Remove(comp);
        }

        Component getChild(int index)
        {
            Component[] childrenArray = children.ToArray();
            return childrenArray[index];
        }

        public virtual string[] ToStringArray()
        {
            string[] retval = new string[20 + this.getCount()]; // Add extra room for the lines that have section names
            retval[0] = name + " (" + getCount() + ")";         // Section name and count
            int currIndex = 1;

            // For each child
            for (int i = 0; i < children.Count; i++)
            {
                // If the child is a section
                if (getChild(i) is Section)
                {
                    // Create a new string array to hold the section's information
                    Section sec = (Section)getChild(i);
                    string[] stringArray = new string[sec.getCount() + 1];

                    // Set each string in the array to an empty string
                    for (int l = 0; l < stringArray.Length; l++)
                        stringArray[l] = "";

                    // Recursive call! 
                    stringArray = sec.ToStringArray();

                    // Copy the new string array to the return array
                    for (int j = 0; j < stringArray.Length; j++)
                    {
                        if (stringArray[j] != null && !stringArray[j].Equals(""))
                        {
                            retval[currIndex] = "    " + stringArray[j]; // Spaces added for visual clarity in the form
                            currIndex++;
                        }
                    }
                }
                // If the child is a musician object, add the name to the array.
                else
                {
                    retval[currIndex] = getChild(i).ToString();
                    currIndex++;
                }
            }
            return retval;   
        }
    }
}
