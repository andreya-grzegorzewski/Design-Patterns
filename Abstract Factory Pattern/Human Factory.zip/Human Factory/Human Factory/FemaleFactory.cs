﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Human_Factory
{
    class FemaleFactory : HumanFactory  // This is a concrete factory
    {
        Random rng = new Random();

        string[] girlNames = { "Andreya", "Abby", "Hannah", "Audrey", "Georgia", "Morgan", "Cheyenne", "Anne", "Jessica" };
        int femaleIndex = 1001; // Start here and increment by 1 for each female created

        public override Person createTestTubePerson(int age)
        {
            string name = "Female " + femaleIndex;
            femaleIndex++;
            return new TestTubeFemale(null, null, name, age);
        }

        public override Person createBaby(Female mom, Male dad)
        {
            string name = girlNames[rng.Next(girlNames.Length)];
            int age = 0;

            return new OrganicFemale(mom, dad, name, age);
        }
    }
}
