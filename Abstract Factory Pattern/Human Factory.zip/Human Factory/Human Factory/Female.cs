﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Human_Factory
{
    public abstract class Female : Person // This is an abstract product
    {
        public abstract string getEyeColor();
        public abstract string getHairColor();
        public abstract void kill();
        public abstract bool canBeAParent();
        public abstract bool isDead();
        public abstract int ageUp();
    }

    public class TestTubeFemale : Female // This is a concrete product
    {
        string name;
        int height; // in inches
        int weight = 0; // in pounds
        int age;    // in months
        string hairColor;
        string eyeColor;
        bool deceased = false;
        Random rng = new Random();
        string[] hairColors = { "brown", "blonde", "black", "red" };
        string[] eyeColors = { "brown", "hazel", "green", "blue" };

        public TestTubeFemale(Female mom, Male dad, string name, int age)
        {
            this.name = name;
            this.age = age;

            if (age > 216)
            {
                weight = 15;
                age = 216;
            }

            // Generated these equations by plotting average height and weight values versus age in months in excel, then generating trendlines
            height = Convert.ToInt32(Math.Floor((-.0008 * age * age) + (.3582 * age) + 24.261));
            weight += Convert.ToInt32(Math.Floor((.0009 * age * age) + (.3853 * age) + 14.122));

            // Randomizes heights and weights slightly
            height += rng.Next(-5, 5);
            weight += rng.Next(-(age / 12), (age / 12));


            hairColor = hairColors[rng.Next(hairColors.Length)];
            eyeColor = eyeColors[rng.Next(eyeColors.Length)];

        }

        public override string ToString()
        {
            string description = name + " - ";

            int feet = 0;
            int inches = height; // Use this so we don't destroy the height variable

            while (inches >= 12)
            {
                feet++;
                inches -= 12;
            }

            description += feet + " feet, " + inches + " inches - ";
            description += weight + " pounds - ";

            int months = age;
            int years = 0;

            while (months >= 12)
            {
                months -= 12;
                years++;
            }

            if (years == 0)
                description += months + " months old. ";
            else
                description += years + " years old. ";

            description += "She has " + hairColor + " hair and " + eyeColor + " eyes.";

            if (this.deceased)
                description = name + " died at " + years + " years old.";

            return description;
        }

        public override bool canBeAParent()
        {
            return (age >= 216 && !this.deceased);    // The person can have babies if he is at least 18 years old
        }

        public override int ageUp()
        {
            age += 12;

            if (age >= 216)
                weight += rng.Next(-3, 5);

            else
            {
                height = Convert.ToInt32(Math.Floor((-.0005 * age * age) + (.3068 * age) + 25.376));
                weight = Convert.ToInt32(Math.Floor((.0016 * age * age) + (.2881 * age) + 16.664));
                height += rng.Next(-5, 5);
                weight += rng.Next(-(age / 12), (age / 12));
            }

            return age;
        }
        
        public override void kill()
        {
            this.deceased = true;
        }

        public override bool isDead()
        {
            return this.deceased;
        }

        public override string getEyeColor()
        {
            return this.eyeColor;
        }

        public override string getHairColor()
        {
            return this.hairColor;
        }
        
    }

    public class OrganicFemale : Female // This is a concrete product
    {
        string name;
        int height; // in inches
        int weight = 0; // in pounds
        int age;    // in months
        string hairColor;
        string eyeColor;
        bool deceased = false;
        Random rng = new Random();
        string[] hairColors = { "brown", "blonde", "black", "red" };
        string[] eyeColors = { "brown", "hazel", "green", "blue" };

        public OrganicFemale(Female mom, Male dad, string name, int age)
        {
            this.name = name;
            this.age = age;

            // Generated these equations by plotting average height and weight values versus age in months in excel, then generating trendlines
            height = Convert.ToInt32(Math.Floor((-.0008 * age * age) + (.3582 * age) + 24.261));
            weight = Convert.ToInt32(Math.Floor((.0009 * age * age) + (.3853 * age) + 14.122));

            // Randomizes heights and weights slightly
            height += rng.Next(-5, 5);
            weight += rng.Next(-(age / 12), (age / 12));

            // Assign eye color based on parents' traits
            if (rng.Next(2) == 0)
                this.eyeColor = mom.getEyeColor();
            else
                this.eyeColor = dad.getEyeColor();


            // Assign hair color based on parents' traits
            if (rng.Next(2) == 0)
                this.hairColor = mom.getHairColor();
            else
                this.hairColor = dad.getHairColor();
        }

        public override string ToString()
        {
            string description = name + " - ";

            int feet = 0;
            int inches = height; // Use this so we don't destroy the height variable

            while (inches >= 12)
            {
                feet++;
                inches -= 12;
            }

            description += feet + " feet, " + inches + " inches - ";
            description += weight + " pounds - ";

            int months = age;
            int years = 0;

            while (months >= 12)
            {
                months -= 12;
                years++;
            }

            if (years == 0)
                description += months + " months old. ";
            else
                description += years + " years old. ";

            description += "She has " + hairColor + " hair and " + eyeColor + " eyes.";

            if (this.deceased)
                description = name + " died at " + years + " years old.";

            return description;
        }

        public override int ageUp()
        {
            age += 12;

            if (age >= 216)
                weight += rng.Next(-3, 5);

            else
            {
                height = Convert.ToInt32(Math.Floor((-.0005 * age * age) + (.3068 * age) + 25.376));
                weight = Convert.ToInt32(Math.Floor((.0016 * age * age) + (.2881 * age) + 16.664));
                height += rng.Next(-5, 5);
                weight += rng.Next(-(age / 12), (age / 12));
            }

            return age;
        }

        public override bool canBeAParent()
        {
            return (age >= 216 && !this.deceased);    // The person can have babies if he is at least 18 years old
        }

        public override void kill()
        {
            this.deceased = true;
        }

        public override bool isDead()
        {
            return this.deceased;
        }

        public override string getEyeColor()
        {
            return this.eyeColor;
        }

        public override string getHairColor()
        {
            return this.hairColor;
        }

    }


}
