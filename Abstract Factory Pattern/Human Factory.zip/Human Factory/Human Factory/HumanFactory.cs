﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Human_Factory
{
    public abstract class HumanFactory // This is the AbstractFactory class
    {
        public abstract Person createTestTubePerson(int age);
        public abstract Person createBaby(Female mom, Male dad);
    }
}
