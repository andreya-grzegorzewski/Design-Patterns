﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Human_Factory
{
    public partial class Form1 : Form
    {
        MaleFactory mf;
        FemaleFactory ff;
        Random rng = new Random();
        List<Female> females = new List<Female>();
        List<Male> males = new List<Male>();

        public Form1()
        {
            InitializeComponent();

            mf = new MaleFactory();
            ff = new FemaleFactory();
        }

        private void testTubeBabyButton_Click(object sender, EventArgs e)
        {
            if (femaleRB.Checked)
            {
                // Creates the female by checking radio boxes
                Female newFemale = null;
                if (babyRB.Checked)     // Create a female two years or younger
                    newFemale = (Female) ff.createTestTubePerson(rng.Next(24));
                else if (childRB.Checked)    // Create a female from 2-12 years
                    newFemale = (Female) ff.createTestTubePerson(rng.Next(24, 144));
                else if (teenagerRB.Checked) // Create a female from 12-18 years
                    newFemale = (Female) ff.createTestTubePerson(rng.Next(144, 216));
                else if (adultRB.Checked)    // Create a female from 18-80 years
                    newFemale = (Female) ff.createTestTubePerson(rng.Next(216, 960));
                else
                    MessageBox.Show("Please select an age.");

                // Add the female to the appropriate lists
                if (newFemale != null)
                {
                    females.Add(newFemale);
                    femaleLB.Items.Add(newFemale.ToString());
                }
            }
            // Repeat
            else if (maleRB.Checked)
            {
                Male newMale = null;

                if (babyRB.Checked)
                    newMale = (Male) mf.createTestTubePerson(rng.Next(24));
                else if (childRB.Checked)
                    newMale = (Male) mf.createTestTubePerson(rng.Next(24, 144));
                else if (teenagerRB.Checked)
                    newMale = (Male) mf.createTestTubePerson(rng.Next(144, 216));
                else if (adultRB.Checked)
                    newMale = (Male) mf.createTestTubePerson(rng.Next(216, 960));
                else
                    MessageBox.Show("Please select an age.");

                if (newMale != null)
                {
                    males.Add(newMale);
                    maleLB.Items.Add(newMale.ToString());
                }
            }
            else
                MessageBox.Show("Please select a gender.");
        }

        private void organicBabyButton_Click(object sender, EventArgs e)
        {
            // Converts the lists to access the necessary element
            Female[] femaleArray = females.ToArray();
            Female mom = femaleArray[femaleLB.SelectedIndex];
            Male[] maleArray = males.ToArray();
            Male dad = maleArray[maleLB.SelectedIndex];

            // Makes sure we have parents who can have children
            if (mom == null || dad == null)
                MessageBox.Show("Please select a mother and a father.");
            else if (!mom.canBeAParent() || !dad.canBeAParent())
                MessageBox.Show("Please make sure both parents are old enough to have kids!");
            
            else
            {
                // Randomly decides if the baby will be a boy or girl
                if (rng.Next(2) == 0)
                {
                    // Creates a new female and adds her to the lists
                    Female newFemale = (Female)ff.createBaby(mom, dad);
                    females.Add(newFemale);
                    femaleLB.Items.Add(newFemale.ToString());
                }
                else
                {
                    // Or creates a new male and adds him to the lists
                    Male newMale = (Male)mf.createBaby(mom, dad);
                    males.Add(newMale);
                    maleLB.Items.Add(newMale.ToString());
                }
            }
        }

        private void ageUpButton_Click(object sender, EventArgs e)
        {
            // Convert lists to arrays for easy access
            Female[] femalesArray = females.ToArray();
            Male[] malesArray = males.ToArray();

            // We clear the list box and re-add each item as we go.
            femaleLB.Items.Clear();
            for (int i = 0; i < femalesArray.Length; i++)
            {
                if (!femalesArray[i].isDead() && femalesArray[i].ageUp() >= 960) // If the person is at least 80...
                    if (rng.Next(5) == 0) // There is a chance...
                        femalesArray[i].kill(); // That they might die :(
                femaleLB.Items.Add(femalesArray[i]);
            }

            // Repeat
            maleLB.Items.Clear();
            for (int i = 0; i < malesArray.Length; i++)
            {
                if (!malesArray[i].isDead() && malesArray[i].ageUp() >= 960)
                    if (rng.Next(5) == 0)
                        malesArray[i].kill();
                maleLB.Items.Add(malesArray[i]);
            }
        }
    }
}
