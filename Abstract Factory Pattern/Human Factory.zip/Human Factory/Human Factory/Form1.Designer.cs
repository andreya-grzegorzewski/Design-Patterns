﻿namespace Human_Factory
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.femaleLB = new System.Windows.Forms.ListBox();
            this.maleLB = new System.Windows.Forms.ListBox();
            this.testTubeBabyButton = new System.Windows.Forms.Button();
            this.organicBabyButton = new System.Windows.Forms.Button();
            this.femaleRB = new System.Windows.Forms.RadioButton();
            this.maleRB = new System.Windows.Forms.RadioButton();
            this.adultRB = new System.Windows.Forms.RadioButton();
            this.childRB = new System.Windows.Forms.RadioButton();
            this.teenagerRB = new System.Windows.Forms.RadioButton();
            this.babyRB = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ageUpButton = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // femaleLB
            // 
            this.femaleLB.FormattingEnabled = true;
            this.femaleLB.Location = new System.Drawing.Point(12, 256);
            this.femaleLB.Name = "femaleLB";
            this.femaleLB.Size = new System.Drawing.Size(517, 160);
            this.femaleLB.TabIndex = 0;
            // 
            // maleLB
            // 
            this.maleLB.FormattingEnabled = true;
            this.maleLB.Location = new System.Drawing.Point(12, 425);
            this.maleLB.Name = "maleLB";
            this.maleLB.Size = new System.Drawing.Size(517, 160);
            this.maleLB.TabIndex = 1;
            // 
            // testTubeBabyButton
            // 
            this.testTubeBabyButton.Location = new System.Drawing.Point(25, 42);
            this.testTubeBabyButton.Name = "testTubeBabyButton";
            this.testTubeBabyButton.Size = new System.Drawing.Size(188, 23);
            this.testTubeBabyButton.TabIndex = 2;
            this.testTubeBabyButton.Text = "Create Test Tube Human";
            this.testTubeBabyButton.UseVisualStyleBackColor = true;
            this.testTubeBabyButton.Click += new System.EventHandler(this.testTubeBabyButton_Click);
            // 
            // organicBabyButton
            // 
            this.organicBabyButton.Location = new System.Drawing.Point(328, 42);
            this.organicBabyButton.Name = "organicBabyButton";
            this.organicBabyButton.Size = new System.Drawing.Size(142, 23);
            this.organicBabyButton.TabIndex = 3;
            this.organicBabyButton.Text = "Create Organic Baby";
            this.organicBabyButton.UseVisualStyleBackColor = true;
            this.organicBabyButton.Click += new System.EventHandler(this.organicBabyButton_Click);
            // 
            // femaleRB
            // 
            this.femaleRB.AutoSize = true;
            this.femaleRB.Location = new System.Drawing.Point(13, 14);
            this.femaleRB.Name = "femaleRB";
            this.femaleRB.Size = new System.Drawing.Size(59, 17);
            this.femaleRB.TabIndex = 4;
            this.femaleRB.TabStop = true;
            this.femaleRB.Text = "Female";
            this.femaleRB.UseVisualStyleBackColor = true;
            // 
            // maleRB
            // 
            this.maleRB.AutoSize = true;
            this.maleRB.Location = new System.Drawing.Point(13, 38);
            this.maleRB.Name = "maleRB";
            this.maleRB.Size = new System.Drawing.Size(48, 17);
            this.maleRB.TabIndex = 5;
            this.maleRB.TabStop = true;
            this.maleRB.Text = "Male";
            this.maleRB.UseVisualStyleBackColor = true;
            // 
            // adultRB
            // 
            this.adultRB.AutoSize = true;
            this.adultRB.Location = new System.Drawing.Point(22, 84);
            this.adultRB.Name = "adultRB";
            this.adultRB.Size = new System.Drawing.Size(49, 17);
            this.adultRB.TabIndex = 7;
            this.adultRB.TabStop = true;
            this.adultRB.Text = "Adult";
            this.adultRB.UseVisualStyleBackColor = true;
            // 
            // childRB
            // 
            this.childRB.AutoSize = true;
            this.childRB.Location = new System.Drawing.Point(22, 38);
            this.childRB.Name = "childRB";
            this.childRB.Size = new System.Drawing.Size(48, 17);
            this.childRB.TabIndex = 9;
            this.childRB.TabStop = true;
            this.childRB.Text = "Child";
            this.childRB.UseVisualStyleBackColor = true;
            // 
            // teenagerRB
            // 
            this.teenagerRB.AutoSize = true;
            this.teenagerRB.Location = new System.Drawing.Point(22, 61);
            this.teenagerRB.Name = "teenagerRB";
            this.teenagerRB.Size = new System.Drawing.Size(71, 17);
            this.teenagerRB.TabIndex = 8;
            this.teenagerRB.TabStop = true;
            this.teenagerRB.Text = "Teenager";
            this.teenagerRB.UseVisualStyleBackColor = true;
            // 
            // babyRB
            // 
            this.babyRB.AutoSize = true;
            this.babyRB.Location = new System.Drawing.Point(21, 15);
            this.babyRB.Name = "babyRB";
            this.babyRB.Size = new System.Drawing.Size(49, 17);
            this.babyRB.TabIndex = 6;
            this.babyRB.TabStop = true;
            this.babyRB.Text = "Baby";
            this.babyRB.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.babyRB);
            this.panel1.Controls.Add(this.teenagerRB);
            this.panel1.Controls.Add(this.childRB);
            this.panel1.Controls.Add(this.adultRB);
            this.panel1.Location = new System.Drawing.Point(108, 81);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(105, 110);
            this.panel1.TabIndex = 10;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.femaleRB);
            this.panel2.Controls.Add(this.maleRB);
            this.panel2.Location = new System.Drawing.Point(25, 81);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(77, 110);
            this.panel2.TabIndex = 11;
            // 
            // ageUpButton
            // 
            this.ageUpButton.Location = new System.Drawing.Point(328, 96);
            this.ageUpButton.Name = "ageUpButton";
            this.ageUpButton.Size = new System.Drawing.Size(142, 23);
            this.ageUpButton.TabIndex = 12;
            this.ageUpButton.Text = "Age Up";
            this.ageUpButton.UseVisualStyleBackColor = true;
            this.ageUpButton.Click += new System.EventHandler(this.ageUpButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(541, 600);
            this.Controls.Add(this.ageUpButton);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.organicBabyButton);
            this.Controls.Add(this.testTubeBabyButton);
            this.Controls.Add(this.maleLB);
            this.Controls.Add(this.femaleLB);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox femaleLB;
        private System.Windows.Forms.ListBox maleLB;
        private System.Windows.Forms.Button testTubeBabyButton;
        private System.Windows.Forms.Button organicBabyButton;
        private System.Windows.Forms.RadioButton femaleRB;
        private System.Windows.Forms.RadioButton maleRB;
        private System.Windows.Forms.RadioButton adultRB;
        private System.Windows.Forms.RadioButton childRB;
        private System.Windows.Forms.RadioButton teenagerRB;
        private System.Windows.Forms.RadioButton babyRB;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button ageUpButton;
    }
}

