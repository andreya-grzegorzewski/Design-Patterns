﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Human_Factory
{
    class MaleFactory : HumanFactory // This is a concrete factory
    {
        Random rng = new Random();
        string[] boyNames = { "Jaired", "Matt", "Jack", "Nathan", "Chris", "Paul", "Adam", "Brayden", "Mike" };
        int maleIndex = 1001;

        public override Person createBaby(Female mom, Male dad)
        {
            string name = boyNames[rng.Next(boyNames.Length)];
            int age = 0;

            return new OrganicMale(mom, dad, name, age);
        }

        public override Person createTestTubePerson(int age)
        {
            string name = "Male " + maleIndex;
            maleIndex++;
            return new TestTubeMale(name, age);
        }
    }
}
